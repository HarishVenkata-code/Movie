//
//  MovieService.swift
//  Movie
//
//  Created by FCI-2171 on 22/08/24.
//

import Foundation

enum APIError: Error, Equatable {
    static func == (lhs: APIError, rhs: APIError) -> Bool {
        return true
    }
    case inValidURL
    case requestFailed(Error)
    case invalidResponse
    case decodingFailed(Error)
}
  
class MovieService {
    func fetchMovieDetails<T: Decodable>(urlString: String, completion: @escaping(Result<T, APIError>) -> Void) {
        guard let url = URL(string: urlString) else {
            return completion(.failure(.inValidURL))
        }
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                return completion(.failure(.requestFailed(error)))
            }
            guard let data = data else {
                return completion(.failure(.invalidResponse))
            }
            
            do {
                let movie = try JSONDecoder().decode(T.self, from: data)
                completion(.success(movie))
                
            }
            catch {
                completion(.failure(.decodingFailed(error)))
                
            }
            
        }
        task.resume()
    }
}
 
