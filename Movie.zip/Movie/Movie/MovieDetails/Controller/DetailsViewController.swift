//
//  DetailsViewController.swift
//  Movie
//
//  Created by FCI-2171 on 22/08/24.
//

import UIKit

class DetailsViewController: BaseViewController {

    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var genre: UILabel!
    @IBOutlet weak var actors: UILabel!
    @IBOutlet weak var director: UILabel!
    @IBOutlet weak var plot: UILabel!
    @IBOutlet weak var boxOffice: UILabel!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var awards: UILabel!

    var viewModel = MovieDetailsViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.activityIndicatorBegin()

        viewModel.getMovieDetails { [weak self] in
            self?.activityIndicatorEnd()
            self?.setupUI()
        }
    }

    private func setupUI() {
        guard let details = viewModel.movieDetails else {
            return
        }

        ImageLoader.sharedInstance.imageForUrl(urlString: details.poster, completionHandler: { (image, url) in
            
            if  image != nil {
                self.movieImage.image = image
            }
        })

        name.text = details.title
        genre.text = details.genre
        actors.text = details.actors
        director.text = details.director
        plot.text = details.plot
        boxOffice.text = details.boxOffice
        rating.text = details.imdbRating
        awards.text = details.awards
    }
}

