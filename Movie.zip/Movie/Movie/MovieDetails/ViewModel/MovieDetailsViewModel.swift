//
//  MovieDetailsViewModel.swift
//  Movie
//
//  Created by FCI-2171 on 22/08/24.
//

import Foundation

class MovieDetailsViewModel: ObservableObject {

    @Published var movieDetails: MovieDetails?
    @Published var errorMessage: String?
    var movie: Movie?

    private let service: MovieService

    init(service: MovieService = MovieService()) {
        self.service = service
    }
        func getMovieDetails(callBack: @escaping()->()) {
            service.fetchMovieDetails(urlString: formingURI()) { [weak self] (result:
                Result<MovieDetails, APIError>) in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let movieInfo):
                        self?.movieDetails = movieInfo
                        callBack()
                    case .failure(let error):
                        self?.errorMessage = error.localizedDescription
                        callBack()
                    }
                }
            }
            
        }

    func formingURI() -> String   {
            guard let movie = movie else {
                return ""
            }
        let url="https://www.omdbapi.com/?t=\(movie.title)&y=\(movie.year)&plot=full&apikey=64e5c48a"
            guard let encodedUrl = url.encodeUrl() else {
                return ""
                }
        return encodedUrl
        
    }
    
}
extension String{
    func encodeUrl() -> String?
    {
        return self.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
    }
}
