//
//  MovieFavData.swift
//  Movie
//
//  Created by FCI-2171 on 22/08/24.
//

import Foundation

struct MovieFavData: Codable{
    let name: String
    let year : String

}
