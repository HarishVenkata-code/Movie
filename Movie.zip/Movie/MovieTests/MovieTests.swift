//
//  MovieTests.swift
//  MovieTests
//
//  Created by FCI-2171 on 22/08/24.
//

import XCTest
@testable import Movie

final class MovieTests: XCTestCase {

    var movieService: MovieService!

    override func setUp() {
        super.setUp()
        movieService = MovieService()
    }

    override func tearDown() {
        movieService = nil
        super.tearDown()
    }

    func testFetchMovieDetails_InvalidURL_ShouldReturnInvalidURLError() {
        let invalidURL = "invalid url"
        let expectation = self.expectation(description: "Completion handler invoked")
        var result: Result<Movie, APIError>?

        movieService.fetchMovieDetails(urlString: invalidURL) { response in
            result = response
            expectation.fulfill()
        }

        waitForExpectations(timeout: 1, handler: nil)

        switch result {
        case .failure(let error):
            XCTAssertEqual(error, .inValidURL)
        default:
            XCTFail("Expected failure with invalidURL but got \(String(describing: result)) instead.")
        }
    }

    func testFetchMovieDetails_DecodingFailed_ShouldReturnDecodingFailedError() {
        let validURL = "https://www.omdbapi.com/?apikey=64e5c48a&type=movie&s=Don"
        let expectation = self.expectation (description: "Completion handler invoked")
        let urlSession = URLSessionMock()
        urlSession.data = "{\"invalid\": \"json\"}".data(using: .utf8)
        
        var result: Result <MockMovie, APIError>?
        movieService.fetchMovieDetails(urlString: validURL) { response in
            result = response
            expectation.fulfill()
        }
        waitForExpectations (timeout: 1, handler: nil)

        switch result {
        case .failure(let error):
            if case .decodingFailed = error {
                // Test passes
            } else {
                XCTFail("Expected decodingFailed error, but got \(error) instead.")
            }
        default:
            XCTFail("Expected failure with decodingFailed, but got \(String(describing: result)) instead.")
        }
    }
}

// Mock classes

struct MockError: Error {}

struct MockMovie: Decodable {
    let title: String
    let year: Int
}

class URLSessionMock: URLSession {
    var data: Data?
    var error: Error?

    override func dataTask(with url: URL, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        completionHandler(data, nil, error)
        return URLSessionDataTaskMock()
    }
}

class URLSessionDataTaskMock: URLSessionDataTask {
    override func resume() {}
}
